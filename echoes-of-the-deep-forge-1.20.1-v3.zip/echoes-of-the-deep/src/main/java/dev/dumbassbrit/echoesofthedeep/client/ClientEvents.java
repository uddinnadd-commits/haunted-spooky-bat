package dev.dumbassbrit.echoesofthedeep.client;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.client.model.EchoWispModel;
import dev.dumbassbrit.echoesofthedeep.client.model.HollowStalkerModel;
import dev.dumbassbrit.echoesofthedeep.client.model.ResonantColossusModel;
import dev.dumbassbrit.echoesofthedeep.client.renderer.EchoWispRenderer;
import dev.dumbassbrit.echoesofthedeep.client.renderer.HollowStalkerRenderer;
import dev.dumbassbrit.echoesofthedeep.client.renderer.ResonantColossusRenderer;
import dev.dumbassbrit.echoesofthedeep.registry.ModEntities;
import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = EchoesOfTheDeep.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {
    }

    @SubscribeEvent
    public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.ECHO_MOTE.get(), EchoMoteParticle.Provider::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(HollowStalkerModel.LAYER, HollowStalkerModel::createBodyLayer);
        event.registerLayerDefinition(EchoWispModel.LAYER, EchoWispModel::createBodyLayer);
        event.registerLayerDefinition(ResonantColossusModel.LAYER, ResonantColossusModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.HOLLOW_STALKER.get(), HollowStalkerRenderer::new);
        event.registerEntityRenderer(ModEntities.ECHO_WISP.get(), EchoWispRenderer::new);
        event.registerEntityRenderer(ModEntities.RESONANT_COLOSSUS.get(), ResonantColossusRenderer::new);
    }
}
