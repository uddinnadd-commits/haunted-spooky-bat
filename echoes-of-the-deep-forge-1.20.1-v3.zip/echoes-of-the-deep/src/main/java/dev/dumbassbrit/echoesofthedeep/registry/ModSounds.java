package dev.dumbassbrit.echoesofthedeep.registry;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, EchoesOfTheDeep.MOD_ID);

    public static final RegistryObject<SoundEvent> RESONANCE_BELL_RING = register("item.resonance_bell.ring");
    public static final RegistryObject<SoundEvent> RESONANCE_BELL_SONAR = register("item.resonance_bell.sonar");
    public static final RegistryObject<SoundEvent> RESONANT_CRYSTAL_CHIME = register("block.resonant_crystal.chime");
    public static final RegistryObject<SoundEvent> HOLLOW_STALKER_AMBIENT = register("entity.hollow_stalker.ambient");
    public static final RegistryObject<SoundEvent> ECHO_WISP_AMBIENT = register("entity.echo_wisp.ambient");
    public static final RegistryObject<SoundEvent> RESONANT_COLOSSUS_AMBIENT = register("entity.resonant_colossus.ambient");
    public static final RegistryObject<SoundEvent> RESONANT_COLOSSUS_AWAKEN = register("entity.resonant_colossus.awaken");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(EchoesOfTheDeep.id(name)));
    }

    private ModSounds() {
    }
}
