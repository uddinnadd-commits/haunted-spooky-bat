package dev.dumbassbrit.echoesofthedeep.client.renderer;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.client.model.EchoWispModel;
import dev.dumbassbrit.echoesofthedeep.entity.EchoWisp;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class EchoWispRenderer extends MobRenderer<EchoWisp, EchoWispModel<EchoWisp>> {
    private static final ResourceLocation TEXTURE = EchoesOfTheDeep.id("textures/entity/echo_wisp.png");
    private static final ResourceLocation GLOW = EchoesOfTheDeep.id("textures/entity/echo_wisp_glow.png");

    public EchoWispRenderer(EntityRendererProvider.Context context) {
        super(context, new EchoWispModel<>(context.bakeLayer(EchoWispModel.LAYER)), 0.25F);
        this.addLayer(new EmissiveLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(EchoWisp entity) {
        return TEXTURE;
    }
}
