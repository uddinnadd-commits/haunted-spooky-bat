package dev.dumbassbrit.echoesofthedeep.client.renderer;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/** Fullbright additive glow layer. It still renders while the entity is invisible, which is how Stalkers "cloak". */
public class EmissiveLayer<T extends LivingEntity, M extends EntityModel<T>> extends EyesLayer<T, M> {
    private final RenderType renderType;

    public EmissiveLayer(RenderLayerParent<T, M> parent, ResourceLocation texture) {
        super(parent);
        this.renderType = RenderType.eyes(texture);
    }

    @Override
    public RenderType renderType() {
        return this.renderType;
    }
}
