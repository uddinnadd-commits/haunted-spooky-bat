# Echoes of the Deep

**Minecraft 1.20.1 · Forge 47.x · requires [TerraBlender](https://www.curseforge.com/minecraft/mc-mods/terrablender)**

![mobs](docs/mobs.png)

Some dark forests aren't dark forests anymore. They're **Echoing Hollows**: teal moss underfoot, glowing Hollow Blooms, Resonant Crystals that sing when you tap them, and echo motes drifting through violet fog.

## Content

| Thing | What it does |
|---|---|
| **Echoing Hollow** (biome) | Takes over some Dark Forest climate slots in new worlds. Custom sky, fog, water, grass and foliage colors, ambient echo motes, crystal chimes in the air, deep dark music. |
| **Echo Moss** | The Hollow's ground cover. Counts as dirt, so trees, flowers and animals work on it. Lets out the occasional mote. |
| **Resonant Crystal** | Glowing cluster (light level 10) on the surface and on cave floors under the Hollow. Right-click it to make it chime. Mine it with a pickaxe for 1-3 Resonant Shards (Fortune works, Silk Touch keeps the crystal). |
| **Hollow Bloom** | A hanging bell-shaped glowing flower. Turns into cyan dye, Night Vision suspicious stew, and bees love it. |
| **Resonant Shard** | The crafting material. |
| **Resonance Bell** | **Use:** a sculk pulse. Monsters within 24 blocks glow for 8 seconds and a double ring of echo motes rolls outward. **Sneak + Use:** ore sonar. Ores within 8 blocks shimmer, and only you can see it. 128 durability, repair it with shards. |


## Mobs

| Mob | Vibe |
|---|---|
| **Hollow Stalker** (hostile) | Tall, hunched sculk hunter. **Cloaked**: you only see its glowing gills, core and spine floating in the dark until it's within 6 blocks, gets hit, or you reveal it with the Resonance Bell. Hits inflict **Darkness**. Spawns in the Echoing Hollow. Drops shards, sculk, and rarely echo shards. |
| **Echo Wisp** (passive, flies) | Glowing jellyfish drifting through the Hollow, trailing motes. Follows you if you're holding a Hollow Bloom. **Feed it a bloom and it crystallises 1-2 Resonant Shards** (2 min cooldown), so shards are renewable. |
| **Resonant Colossus** (boss) | 300 HP crystal and deepslate giant with a boss bar. **Slam:** a shockwave hits everything around it. **Sonic Pulse:** it charges (motes rush into its chest) then fires a beam. **Enrage below 50%:** purple bar, roar, faster, harder pulses, and it summons 2 Hollow Stalkers. |

### Summoning the Colossus
Craft a **Hollow Heart** (Hollow Blooms in the corners, Resonant Shards on the sides, Eye of Ender in the middle), then use it on a **Resonant Crystal**.

### Loot
**Colossus Core** + a pile of shards, amethyst and echo shards. Core + 2 shards + 2 sticks = **Resonant Blade** (9 damage, 1800 durability, every hit makes the target glow and slows it, with a crystal chime and particle burst).

### Recipes
- **Resonance Bell:** iron nugget (top middle), shard / amethyst shard / shard (middle row), three shards (bottom row)
- **Echo Moss ×2:** Moss Block + Resonant Shard
- **Cyan Dye:** Hollow Bloom
- **Hollow Heart:** see above
- **Resonant Blade:** shard, shard (column), stick / Colossus Core / stick (bottom row)

### VFX & audio
- Custom fullbright `echo_mote` particle that rises and fades, with a cyan-to-violet tint
- Expanding pulse rings sent from the server, so every nearby player sees them
- Sculk charge pops on every monster the pulse reveals
- Emissive glow layers on every mob (Stalkers stay visible as glowing fragments while cloaked)
- Boss charge-up, beam, shockwave, enrage and death VFX
- 9 original synthesized sounds: bell ring, sonar ping, crystal chimes, Stalker echolocation clicks, Wisp chirps, Colossus hum and awakening

### Config
`config/echoesofthedeep-common.toml`: pulse radius, glow duration, sonar radius, cooldown.

## Building

Needs Java 17 and Gradle 8.8:

```sh
gradle build
```

The jar goes to `build/libs/`. Install it alongside **TerraBlender (Forge) 1.20.1**.

## GitHub Actions
`.github/workflows/build.yml` builds the mod on every push and pull request (and you can run it by hand). Grab the jar from the run's **Artifacts**. Push a tag like `v2.0.0` and it also publishes a GitHub Release with the jar attached.

## Notes
- The biome only shows up in **newly generated chunks**.
- Find it fast with `/locate biome echoesofthedeep:echoing_hollow`

MIT licensed.
