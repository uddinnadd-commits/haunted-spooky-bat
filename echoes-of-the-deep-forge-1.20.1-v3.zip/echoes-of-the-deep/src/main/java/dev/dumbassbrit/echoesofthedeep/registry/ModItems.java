package dev.dumbassbrit.echoesofthedeep.registry;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.item.HollowHeartItem;
import dev.dumbassbrit.echoesofthedeep.item.ResonanceBellItem;
import dev.dumbassbrit.echoesofthedeep.item.ResonantBladeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, EchoesOfTheDeep.MOD_ID);

    public static final RegistryObject<Item> RESONANT_SHARD = ITEMS.register("resonant_shard",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> RESONANCE_BELL = ITEMS.register("resonance_bell",
            () -> new ResonanceBellItem(new Item.Properties().durability(128).rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> ECHO_MOSS = ITEMS.register("echo_moss",
            () -> new BlockItem(ModBlocks.ECHO_MOSS.get(), new Item.Properties()));

    public static final RegistryObject<Item> RESONANT_CRYSTAL = ITEMS.register("resonant_crystal",
            () -> new BlockItem(ModBlocks.RESONANT_CRYSTAL.get(), new Item.Properties()));

    public static final RegistryObject<Item> HOLLOW_BLOOM = ITEMS.register("hollow_bloom",
            () -> new BlockItem(ModBlocks.HOLLOW_BLOOM.get(), new Item.Properties()));

    public static final RegistryObject<Item> HOLLOW_HEART = ITEMS.register("hollow_heart",
            () -> new HollowHeartItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> COLOSSUS_CORE = ITEMS.register("colossus_core",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> RESONANT_BLADE = ITEMS.register("resonant_blade",
            () -> new ResonantBladeItem(new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> HOLLOW_STALKER_SPAWN_EGG = ITEMS.register("hollow_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HOLLOW_STALKER, 0x141C2E, 0x5FE3EF, new Item.Properties()));

    public static final RegistryObject<Item> ECHO_WISP_SPAWN_EGG = ITEMS.register("echo_wisp_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ECHO_WISP, 0xB9A3FF, 0x8FFCF0, new Item.Properties()));

    public static final RegistryObject<Item> RESONANT_COLOSSUS_SPAWN_EGG = ITEMS.register("resonant_colossus_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.RESONANT_COLOSSUS, 0x2D2F38, 0x3A8AD6, new Item.Properties()));

    private ModItems() {
    }
}
