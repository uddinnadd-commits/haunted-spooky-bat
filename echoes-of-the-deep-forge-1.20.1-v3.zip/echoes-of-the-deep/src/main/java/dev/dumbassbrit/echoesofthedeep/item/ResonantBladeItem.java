package dev.dumbassbrit.echoesofthedeep.item;

import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import dev.dumbassbrit.echoesofthedeep.registry.ModSounds;
import dev.dumbassbrit.echoesofthedeep.registry.ModTiers;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Forged from the Colossus Core. Every hit rings: the target glows, slows, and bursts with echo motes. */
public class ResonantBladeItem extends SwordItem {
    public ResonantBladeItem(Properties properties) {
        super(ModTiers.RESONANT, 4, -2.4F, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0), attacker);
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1), attacker);
        if (attacker.level() instanceof ServerLevel level) {
            level.sendParticles(ModParticles.ECHO_MOTE.get(), target.getX(), target.getY(0.5D), target.getZ(),
                    16, 0.3D, 0.4D, 0.3D, 0.08D);
            level.sendParticles(ParticleTypes.SCULK_CHARGE_POP, target.getX(), target.getY(0.5D), target.getZ(),
                    6, 0.3D, 0.4D, 0.3D, 0.02D);
            level.playSound(null, target.getX(), target.getY(), target.getZ(), ModSounds.RESONANT_CRYSTAL_CHIME.get(),
                    SoundSource.PLAYERS, 0.8F, 1.3F + attacker.getRandom().nextFloat() * 0.3F);
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.echoesofthedeep.resonant_blade.tooltip").withStyle(ChatFormatting.DARK_AQUA));
    }
}
