package dev.dumbassbrit.echoesofthedeep.registry;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;

/** The biome itself is data-driven: data/echoesofthedeep/worldgen/biome/echoing_hollow.json */
public final class ModBiomes {
    public static final ResourceKey<Biome> ECHOING_HOLLOW =
            ResourceKey.create(Registries.BIOME, EchoesOfTheDeep.id("echoing_hollow"));

    private ModBiomes() {
    }
}
