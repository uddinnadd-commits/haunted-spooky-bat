package dev.dumbassbrit.echoesofthedeep.client.renderer;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.client.model.ResonantColossusModel;
import dev.dumbassbrit.echoesofthedeep.entity.ResonantColossus;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ResonantColossusRenderer extends MobRenderer<ResonantColossus, ResonantColossusModel<ResonantColossus>> {
    private static final ResourceLocation TEXTURE = EchoesOfTheDeep.id("textures/entity/resonant_colossus.png");
    private static final ResourceLocation GLOW = EchoesOfTheDeep.id("textures/entity/resonant_colossus_glow.png");

    public ResonantColossusRenderer(EntityRendererProvider.Context context) {
        super(context, new ResonantColossusModel<>(context.bakeLayer(ResonantColossusModel.LAYER)), 1.4F);
        this.addLayer(new EmissiveLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(ResonantColossus entity) {
        return TEXTURE;
    }
}
