package dev.dumbassbrit.echoesofthedeep;

import com.mojang.logging.LogUtils;
import dev.dumbassbrit.echoesofthedeep.registry.ModBlocks;
import dev.dumbassbrit.echoesofthedeep.registry.ModCreativeTabs;
import dev.dumbassbrit.echoesofthedeep.registry.ModEntities;
import dev.dumbassbrit.echoesofthedeep.registry.ModItems;
import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import dev.dumbassbrit.echoesofthedeep.registry.ModSounds;
import dev.dumbassbrit.echoesofthedeep.worldgen.EchoingHollowRegion;
import dev.dumbassbrit.echoesofthedeep.worldgen.ModSurfaceRules;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import terrablender.api.Regions;
import terrablender.api.SurfaceRuleManager;

@Mod(EchoesOfTheDeep.MOD_ID)
public final class EchoesOfTheDeep {
    public static final String MOD_ID = "echoesofthedeep";
    public static final Logger LOGGER = LogUtils.getLogger();

    /** Weight of our TerraBlender region. Vanilla's region weight defaults to 10. */
    private static final int REGION_WEIGHT = 4;

    public EchoesOfTheDeep() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModParticles.PARTICLES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        modBus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, EchoesConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            Regions.register(new EchoingHollowRegion(id("overworld"), REGION_WEIGHT));
            SurfaceRuleManager.addSurfaceRules(SurfaceRuleManager.RuleCategory.OVERWORLD, MOD_ID, ModSurfaceRules.makeRules());
            LOGGER.info("Echoes of the Deep: the Echoing Hollow is listening.");
        });
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
