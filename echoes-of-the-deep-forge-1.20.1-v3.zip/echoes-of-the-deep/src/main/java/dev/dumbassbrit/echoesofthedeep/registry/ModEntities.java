package dev.dumbassbrit.echoesofthedeep.registry;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.entity.EchoWisp;
import dev.dumbassbrit.echoesofthedeep.entity.HollowStalker;
import dev.dumbassbrit.echoesofthedeep.entity.ResonantColossus;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EchoesOfTheDeep.MOD_ID);

    public static final RegistryObject<EntityType<HollowStalker>> HOLLOW_STALKER = ENTITIES.register("hollow_stalker",
            () -> EntityType.Builder.of(HollowStalker::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.6F)
                    .clientTrackingRange(10)
                    .build("hollow_stalker"));

    public static final RegistryObject<EntityType<EchoWisp>> ECHO_WISP = ENTITIES.register("echo_wisp",
            () -> EntityType.Builder.of(EchoWisp::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.0F)
                    .clientTrackingRange(8)
                    .build("echo_wisp"));

    public static final RegistryObject<EntityType<ResonantColossus>> RESONANT_COLOSSUS = ENTITIES.register("resonant_colossus",
            () -> EntityType.Builder.of(ResonantColossus::new, MobCategory.MONSTER)
                    .sized(2.0F, 3.4F)
                    .clientTrackingRange(12)
                    .fireImmune()
                    .build("resonant_colossus"));

    private ModEntities() {
    }
}
