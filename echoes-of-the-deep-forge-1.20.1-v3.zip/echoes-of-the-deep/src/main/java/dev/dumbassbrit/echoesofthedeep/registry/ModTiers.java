package dev.dumbassbrit.echoesofthedeep.registry;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public final class ModTiers {
    public static final Tier RESONANT = new Tier() {
        @Override
        public int getUses() {
            return 1800;
        }

        @Override
        public float getSpeed() {
            return 9.0F;
        }

        @Override
        public float getAttackDamageBonus() {
            return 4.0F;
        }

        @Override
        public int getLevel() {
            return 4;
        }

        @Override
        public int getEnchantmentValue() {
            return 18;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(ModItems.RESONANT_SHARD.get());
        }
    };

    private ModTiers() {
    }
}
