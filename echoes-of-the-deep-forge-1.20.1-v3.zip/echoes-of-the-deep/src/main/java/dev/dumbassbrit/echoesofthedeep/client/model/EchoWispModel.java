package dev.dumbassbrit.echoesofthedeep.client.model;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.entity.EchoWisp;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Geometry generated from the same spec as the skin texture, so UVs always line up. Animation is hand-written. */
@SuppressWarnings("unused")
public class EchoWispModel<T extends EchoWisp> extends HierarchicalModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(EchoesOfTheDeep.id("echo_wisp"), "main");
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart tentacle1;
    private final ModelPart tentacle2;
    private final ModelPart tentacle3;
    private final ModelPart tentacle4;
    private final ModelPart tentacle5;

    public EchoWispModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.tentacle1 = this.body.getChild("tentacle_1");
        this.tentacle2 = this.body.getChild("tentacle_2");
        this.tentacle3 = this.body.getChild("tentacle_3");
        this.tentacle4 = this.body.getChild("tentacle_4");
        this.tentacle5 = this.body.getChild("tentacle_5");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -4.0F, 8.0F, 6.0F, 8.0F).texOffs(0, 25).addBox(-2.0F, -9.0F, -2.0F, 4.0F, 2.0F, 4.0F).texOffs(0, 14).addBox(-5.0F, -1.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offset(0.0F, 15.0F, 0.0F));
        PartDefinition tentacle1 = body.addOrReplaceChild("tentacle_1", CubeListBuilder.create().texOffs(48, 14).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offset(3.0F, 0.0F, 3.0F));
        PartDefinition tentacle2 = body.addOrReplaceChild("tentacle_2", CubeListBuilder.create().texOffs(52, 14).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offset(-3.0F, 0.0F, 3.0F));
        PartDefinition tentacle3 = body.addOrReplaceChild("tentacle_3", CubeListBuilder.create().texOffs(56, 14).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offset(3.0F, 0.0F, -3.0F));
        PartDefinition tentacle4 = body.addOrReplaceChild("tentacle_4", CubeListBuilder.create().texOffs(60, 14).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offset(-3.0F, 0.0F, -3.0F));
        PartDefinition tentacle5 = body.addOrReplaceChild("tentacle_5", CubeListBuilder.create().texOffs(40, 14).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float bob = Mth.sin(ageInTicks * 0.12F);
        this.body.y += bob * 1.2F;
        float pulse = 1.0F + Mth.sin(ageInTicks * 0.2F) * 0.06F;
        this.body.xScale = pulse;
        this.body.zScale = pulse;
        this.body.yScale = 2.0F - pulse;
        this.body.yRot += ageInTicks * 0.02F;
        ModelPart[] tentacles = {this.tentacle1, this.tentacle2, this.tentacle3, this.tentacle4, this.tentacle5};
        for (int i = 0; i < tentacles.length; i++) {
            float phase = ageInTicks * 0.18F + i * 1.3F;
            tentacles[i].xRot += Mth.sin(phase) * 0.25F + limbSwingAmount * 0.6F;
            tentacles[i].zRot += Mth.cos(phase * 0.8F) * 0.2F;
        }
    }
}
