package dev.dumbassbrit.echoesofthedeep.block;

import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** A pale glowing flower. Suspicious stew made from it grants Night Vision. */
public class HollowBloomBlock extends FlowerBlock {
    public HollowBloomBlock(Properties properties) {
        super(() -> MobEffects.NIGHT_VISION, 8, properties);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(8) == 0) {
            Vec3 offset = state.getOffset(level, pos);
            level.addParticle(ModParticles.ECHO_MOTE.get(),
                    pos.getX() + 0.5D + offset.x + (random.nextDouble() - 0.5D) * 0.3D,
                    pos.getY() + 0.6D + random.nextDouble() * 0.2D,
                    pos.getZ() + 0.5D + offset.z + (random.nextDouble() - 0.5D) * 0.3D,
                    0.0D, 0.015D, 0.0D);
        }
    }
}
