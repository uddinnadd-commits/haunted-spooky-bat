package dev.dumbassbrit.echoesofthedeep.item;

import dev.dumbassbrit.echoesofthedeep.entity.ResonantColossus;
import dev.dumbassbrit.echoesofthedeep.registry.ModBlocks;
import dev.dumbassbrit.echoesofthedeep.registry.ModEntities;
import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import dev.dumbassbrit.echoesofthedeep.registry.ModSounds;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Use on a Resonant Crystal to awaken the Resonant Colossus. */
public class HollowHeartItem extends Item {
    public HollowHeartItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        Player player = context.getPlayer();

        if (!level.getBlockState(pos).is(ModBlocks.RESONANT_CRYSTAL.get())) {
            if (!level.isClientSide && player != null) {
                player.displayClientMessage(Component.translatable("message.echoesofthedeep.heart_needs_crystal")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return InteractionResult.FAIL;
        }

        if (level instanceof ServerLevel serverLevel) {
            ResonantColossus colossus = ModEntities.RESONANT_COLOSSUS.get().create(serverLevel);
            if (colossus == null) {
                return InteractionResult.FAIL;
            }
            serverLevel.removeBlock(pos, false);
            float yaw = player != null ? player.getYRot() + 180.0F : 0.0F;
            colossus.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, yaw, 0.0F);
            colossus.setYHeadRot(yaw);
            serverLevel.addFreshEntity(colossus);

            double x = pos.getX() + 0.5D;
            double z = pos.getZ() + 0.5D;
            for (int i = 0; i < 40; i++) {
                serverLevel.sendParticles(ModParticles.ECHO_MOTE.get(), x, pos.getY() + i * 0.2D, z, 6, 0.4D, 0.1D, 0.4D, 0.05D);
            }
            for (int i = 0; i < 64; i++) {
                double angle = (Math.PI * 2.0D * i) / 64.0D;
                serverLevel.sendParticles(ModParticles.ECHO_MOTE.get(), x, pos.getY() + 0.3D, z, 0,
                        Math.cos(angle), 0.0D, Math.sin(angle), 0.9D);
            }
            serverLevel.sendParticles(ParticleTypes.SCULK_SOUL, x, pos.getY() + 1.5D, z, 80, 1.0D, 1.5D, 1.0D, 0.06D);
            serverLevel.sendParticles(ParticleTypes.FLASH, x, pos.getY() + 1.5D, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            serverLevel.playSound(null, pos, ModSounds.RESONANT_COLOSSUS_AWAKEN.get(), SoundSource.HOSTILE, 4.0F, 1.0F);

            if (player == null || !player.getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.echoesofthedeep.hollow_heart.tooltip").withStyle(ChatFormatting.DARK_PURPLE));
    }
}
