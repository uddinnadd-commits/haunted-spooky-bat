package dev.dumbassbrit.echoesofthedeep.worldgen;

import com.mojang.datafixers.util.Pair;
import dev.dumbassbrit.echoesofthedeep.registry.ModBiomes;
import java.util.function.Consumer;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import terrablender.api.Region;
import terrablender.api.RegionType;

/**
 * A TerraBlender region that is vanilla overworld terrain, except dark forests become Echoing Hollows.
 * Swapping into existing climate slots keeps terrain natural and avoids weird biome borders.
 */
public class EchoingHollowRegion extends Region {
    public EchoingHollowRegion(ResourceLocation name, int weight) {
        super(name, RegionType.OVERWORLD, weight);
    }

    @Override
    public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
        this.addModifiedVanillaOverworldBiomes(mapper, builder -> builder.replaceBiome(Biomes.DARK_FOREST, ModBiomes.ECHOING_HOLLOW));
    }
}
