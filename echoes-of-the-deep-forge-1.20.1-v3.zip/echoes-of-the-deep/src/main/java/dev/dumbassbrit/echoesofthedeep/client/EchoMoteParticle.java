package dev.dumbassbrit.echoesofthedeep.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** Fullbright, slowly rising, fading mote tinted somewhere between sculk cyan and amethyst violet. */
public class EchoMoteParticle extends TextureSheetParticle {
    private static final int FULL_BRIGHT = 0xF000F0;
    private final SpriteSet sprites;

    protected EchoMoteParticle(ClientLevel level, double x, double y, double z,
                               double xSpeed, double ySpeed, double zSpeed, SpriteSet sprites) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.xd = xSpeed;
        this.yd = ySpeed;
        this.zd = zSpeed;
        this.friction = 0.9F;
        this.gravity = -0.012F;
        this.hasPhysics = false;
        this.lifetime = 30 + this.random.nextInt(20);
        this.quadSize = 0.07F + this.random.nextFloat() * 0.07F;

        float t = this.random.nextFloat();
        this.rCol = Mth.lerp(t, 0.30F, 0.78F);
        this.gCol = Mth.lerp(t, 0.98F, 0.55F);
        this.bCol = 1.0F;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.removed) {
            this.setSpriteFromAge(this.sprites);
            float life = (float) this.age / (float) this.lifetime;
            this.alpha = Mth.clamp(1.0F - life * life, 0.0F, 1.0F);
        }
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) {
        return FULL_BRIGHT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xSpeed, double ySpeed, double zSpeed) {
            return new EchoMoteParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
        }
    }
}
