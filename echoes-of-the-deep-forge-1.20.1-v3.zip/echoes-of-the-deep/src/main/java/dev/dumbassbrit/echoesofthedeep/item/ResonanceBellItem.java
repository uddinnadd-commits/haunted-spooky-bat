package dev.dumbassbrit.echoesofthedeep.item;

import dev.dumbassbrit.echoesofthedeep.EchoesConfig;
import dev.dumbassbrit.echoesofthedeep.registry.ModItems;
import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import dev.dumbassbrit.echoesofthedeep.registry.ModSounds;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.Tags;

/**
 * Right-click: a sculk pulse that makes nearby monsters glow, with an expanding ring of echo motes.
 * Sneak + right-click: ore sonar, nearby ores shimmer (only the user sees it).
 */
public class ResonanceBellItem extends Item {
    private static final int RING_POINTS = 72;
    private static final int MAX_SONAR_MARKERS = 160;

    public ResonanceBellItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
            if (player.isShiftKeyDown()) {
                sonar(serverLevel, serverPlayer);
            } else {
                pulse(serverLevel, serverPlayer);
            }
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.getCooldowns().addCooldown(this, EchoesConfig.COOLDOWN_TICKS.get());
            player.awardStat(Stats.ITEM_USED.get(this));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private static void pulse(ServerLevel level, ServerPlayer player) {
        int radius = EchoesConfig.PULSE_RADIUS.get();
        int glowTicks = EchoesConfig.GLOW_SECONDS.get() * 20;
        double radiusSq = (double) radius * radius;

        AABB area = player.getBoundingBox().inflate(radius);
        List<Monster> monsters = level.getEntitiesOfClass(Monster.class, area,
                monster -> monster.isAlive() && monster.distanceToSqr(player) <= radiusSq);

        for (Monster monster : monsters) {
            monster.addEffect(new MobEffectInstance(MobEffects.GLOWING, glowTicks, 0, false, false, true));
            level.sendParticles(ParticleTypes.SCULK_CHARGE_POP,
                    monster.getX(), monster.getY() + monster.getBbHeight() * 0.5D, monster.getZ(),
                    8, 0.3D, 0.4D, 0.3D, 0.02D);
        }

        // Two expanding rings: a fast wide one and a slower inner echo.
        double cx = player.getX();
        double cy = player.getY() + 0.9D;
        double cz = player.getZ();
        for (int i = 0; i < RING_POINTS; i++) {
            double angle = (Math.PI * 2.0D * i) / RING_POINTS;
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            // count = 0 makes (dx, dy, dz) the particle velocity, scaled by speed
            level.sendParticles(ModParticles.ECHO_MOTE.get(), cx + dx * 0.5D, cy, cz + dz * 0.5D, 0, dx, 0.0D, dz, 0.75D);
            if (i % 2 == 0) {
                level.sendParticles(ModParticles.ECHO_MOTE.get(), cx + dx * 0.3D, cy - 0.4D, cz + dz * 0.3D, 0, dx, 0.05D, dz, 0.35D);
            }
        }
        level.sendParticles(ParticleTypes.SCULK_SOUL, cx, cy, cz, 12, 0.4D, 0.3D, 0.4D, 0.05D);

        level.playSound(null, cx, player.getY(), cz, ModSounds.RESONANCE_BELL_RING.get(), SoundSource.PLAYERS,
                1.2F, 0.9F + level.getRandom().nextFloat() * 0.2F);
        player.displayClientMessage(Component.translatable("message.echoesofthedeep.pulse", monsters.size())
                .withStyle(ChatFormatting.DARK_AQUA), true);
    }

    private static void sonar(ServerLevel level, ServerPlayer player) {
        int radius = EchoesConfig.SONAR_RADIUS.get();
        BlockPos origin = player.blockPosition();
        int found = 0;

        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-radius, -radius, -radius), origin.offset(radius, radius, radius))) {
            BlockState state = level.getBlockState(pos);
            if (state.is(Tags.Blocks.ORES)) {
                found++;
                if (found <= MAX_SONAR_MARKERS) {
                    // Sent only to the bell's user, so sonar stays private.
                    level.sendParticles(player, ModParticles.ECHO_MOTE.get(), true,
                            pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                            5, 0.3D, 0.3D, 0.3D, 0.0D);
                }
            }
        }

        level.sendParticles(ParticleTypes.SCULK_CHARGE_POP, player.getX(), player.getY() + 1.0D, player.getZ(),
                20, 0.6D, 0.6D, 0.6D, 0.04D);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.RESONANCE_BELL_SONAR.get(),
                SoundSource.PLAYERS, 1.0F, 1.0F);
        player.displayClientMessage(Component.translatable("message.echoesofthedeep.sonar", found)
                .withStyle(ChatFormatting.LIGHT_PURPLE), true);
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repairCandidate) {
        return repairCandidate.is(ModItems.RESONANT_SHARD.get());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.echoesofthedeep.resonance_bell.tooltip.use").withStyle(ChatFormatting.DARK_AQUA));
        tooltip.add(Component.translatable("item.echoesofthedeep.resonance_bell.tooltip.sneak").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("item.echoesofthedeep.resonance_bell.tooltip.repair").withStyle(ChatFormatting.GRAY));
    }
}
