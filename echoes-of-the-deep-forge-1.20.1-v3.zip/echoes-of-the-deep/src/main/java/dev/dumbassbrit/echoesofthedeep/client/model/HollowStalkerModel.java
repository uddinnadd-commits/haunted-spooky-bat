package dev.dumbassbrit.echoesofthedeep.client.model;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.entity.HollowStalker;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Geometry generated from the same spec as the skin texture, so UVs always line up. Animation is hand-written. */
@SuppressWarnings("unused")
public class HollowStalkerModel<T extends HollowStalker> extends HierarchicalModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(EchoesOfTheDeep.id("hollow_stalker"), "main");
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftFin;
    private final ModelPart rightFin;
    private final ModelPart spine;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public HollowStalkerModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.leftFin = this.head.getChild("left_fin");
        this.rightFin = this.head.getChild("right_fin");
        this.spine = this.body.getChild("spine");
        this.rightArm = this.body.getChild("right_arm");
        this.leftArm = this.body.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(24, 0).addBox(-4.0F, -16.0F, -2.5F, 8.0F, 16.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.35F, 0.0F, 0.0F));
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(12, 25).addBox(-3.5F, -7.0F, -5.0F, 7.0F, 7.0F, 8.0F).texOffs(44, 46).addBox(-2.5F, -1.0F, -5.5F, 5.0F, 2.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -16.0F, -0.5F, -0.35F, 0.0F, 0.0F));
        PartDefinition leftFin = head.addOrReplaceChild("left_fin", CubeListBuilder.create().texOffs(42, 25).addBox(0.0F, -3.0F, -2.0F, 1.0F, 6.0F, 5.0F), PartPose.offset(3.5F, -4.0F, -1.0F));
        PartDefinition rightFin = head.addOrReplaceChild("right_fin", CubeListBuilder.create().texOffs(0, 46).addBox(-1.0F, -3.0F, -2.0F, 1.0F, 6.0F, 5.0F), PartPose.offset(-3.5F, -4.0F, -1.0F));
        PartDefinition spine = body.addOrReplaceChild("spine", CubeListBuilder.create().texOffs(0, 57).addBox(-1.0F, -15.0F, 2.5F, 2.0F, 3.0F, 3.0F).texOffs(10, 57).addBox(-1.0F, -10.0F, 2.5F, 2.0F, 3.0F, 2.0F).texOffs(18, 57).addBox(-1.0F, -5.0F, 2.5F, 2.0F, 2.0F, 2.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition rightArm = body.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -1.0F, -1.5F, 3.0F, 22.0F, 3.0F).texOffs(12, 46).addBox(-2.5F, 20.0F, -2.0F, 4.0F, 5.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -14.5F, 0.0F, -0.35F, 0.0F, 0.1F));
        PartDefinition leftArm = body.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(12, 0).addBox(-1.0F, -1.0F, -1.5F, 3.0F, 22.0F, 3.0F).texOffs(28, 46).addBox(-1.5F, 20.0F, -2.0F, 4.0F, 5.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -14.5F, 0.0F, -0.35F, 0.0F, -0.1F));
        PartDefinition rightLeg = root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(50, 0).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 18.0F, 3.0F), PartPose.offset(-2.2F, 6.0F, 0.5F));
        PartDefinition leftLeg = root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 25).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 18.0F, 3.0F), PartPose.offset(2.2F, 6.0F, 0.5F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float walk = limbSwing * 0.6662F;
        this.rightLeg.xRot += Mth.cos(walk) * 1.1F * limbSwingAmount;
        this.leftLeg.xRot += Mth.cos(walk + Mth.PI) * 1.1F * limbSwingAmount;
        this.rightArm.xRot += Mth.cos(walk + Mth.PI) * 0.8F * limbSwingAmount + Mth.sin(ageInTicks * 0.067F) * 0.06F;
        this.leftArm.xRot += Mth.cos(walk) * 0.8F * limbSwingAmount - Mth.sin(ageInTicks * 0.067F) * 0.06F;
        this.rightArm.zRot += Mth.cos(ageInTicks * 0.09F) * 0.05F;
        this.leftArm.zRot -= Mth.cos(ageInTicks * 0.09F) * 0.05F;
        this.head.yRot += netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot += headPitch * Mth.DEG_TO_RAD;
        // twitchy "listening" head tilt and fluttering gills
        this.head.zRot += Mth.sin(ageInTicks * 0.21F) * Mth.sin(ageInTicks * 0.05F) * 0.12F;
        this.leftFin.yRot += 0.25F + Mth.sin(ageInTicks * 0.35F) * 0.3F;
        this.rightFin.yRot -= 0.25F + Mth.sin(ageInTicks * 0.35F) * 0.3F;
        this.body.xRot += Mth.sin(ageInTicks * 0.05F) * 0.03F;
        if (this.attackTime > 0.0F) {
            float swing = Mth.sin(this.attackTime * Mth.PI);
            this.rightArm.xRot -= swing * 2.0F;
            this.leftArm.xRot -= swing * 1.6F;
            this.body.xRot += swing * 0.25F;
        }
    }
}
