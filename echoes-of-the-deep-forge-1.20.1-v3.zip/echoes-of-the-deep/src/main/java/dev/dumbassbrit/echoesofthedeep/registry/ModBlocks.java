package dev.dumbassbrit.echoesofthedeep.registry;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.block.EchoMossBlock;
import dev.dumbassbrit.echoesofthedeep.block.HollowBloomBlock;
import dev.dumbassbrit.echoesofthedeep.block.ResonantCrystalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, EchoesOfTheDeep.MOD_ID);

    public static final RegistryObject<Block> ECHO_MOSS = BLOCKS.register("echo_moss",
            () -> new EchoMossBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(0.6F)
                    .sound(SoundType.MOSS)));

    public static final RegistryObject<Block> RESONANT_CRYSTAL = BLOCKS.register("resonant_crystal",
            () -> new ResonantCrystalBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(1.5F)
                    .sound(SoundType.AMETHYST_CLUSTER)
                    .lightLevel(state -> 10)
                    .noOcclusion()
                    .requiresCorrectToolForDrops()
                    .pushReaction(PushReaction.DESTROY)));

    public static final RegistryObject<Block> HOLLOW_BLOOM = BLOCKS.register("hollow_bloom",
            () -> new HollowBloomBlock(BlockBehaviour.Properties.copy(Blocks.ALLIUM)
                    .mapColor(MapColor.COLOR_LIGHT_BLUE)
                    .lightLevel(state -> 6)));

    private ModBlocks() {
    }
}
