package dev.dumbassbrit.echoesofthedeep;

import net.minecraftforge.common.ForgeConfigSpec;

public final class EchoesConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue PULSE_RADIUS;
    public static final ForgeConfigSpec.IntValue GLOW_SECONDS;
    public static final ForgeConfigSpec.IntValue SONAR_RADIUS;
    public static final ForgeConfigSpec.IntValue COOLDOWN_TICKS;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("resonance_bell");
        PULSE_RADIUS = builder
                .comment("Radius (blocks) of the monster-revealing pulse.")
                .defineInRange("pulseRadius", 24, 4, 64);
        GLOW_SECONDS = builder
                .comment("How long revealed monsters glow, in seconds.")
                .defineInRange("glowSeconds", 8, 1, 60);
        SONAR_RADIUS = builder
                .comment("Radius (blocks) of the sneak-use ore sonar. Larger values cost more server time.")
                .defineInRange("sonarRadius", 8, 2, 16);
        COOLDOWN_TICKS = builder
                .comment("Cooldown between rings, in ticks (20 ticks = 1 second).")
                .defineInRange("cooldownTicks", 80, 0, 1200);
        builder.pop();
        SPEC = builder.build();
    }

    private EchoesConfig() {
    }
}
