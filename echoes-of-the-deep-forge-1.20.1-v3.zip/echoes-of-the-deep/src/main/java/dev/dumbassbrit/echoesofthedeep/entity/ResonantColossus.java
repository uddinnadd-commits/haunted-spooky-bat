package dev.dumbassbrit.echoesofthedeep.entity;

import dev.dumbassbrit.echoesofthedeep.registry.ModEntities;
import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import dev.dumbassbrit.echoesofthedeep.registry.ModSounds;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Boss. A walking cathedral of deepslate and resonant crystal.
 * - Melee slams that send a shockwave through everything nearby
 * - Charges and fires a sonic pulse beam at range
 * - Below half health it enrages: faster, harder hitting, and calls two Hollow Stalkers
 */
public class ResonantColossus extends Monster {
    private static final EntityDataAccessor<Boolean> DATA_CHARGING =
            SynchedEntityData.defineId(ResonantColossus.class, EntityDataSerializers.BOOLEAN);
    private static final UUID ENRAGE_SPEED_ID = UUID.fromString("6f1c2a52-3a4e-4d8b-9d3f-0c8f2b7e9a11");
    private static final int CHARGE_TIME = 24;
    private static final double PULSE_RANGE_SQR = 24.0D * 24.0D;

    private final ServerBossEvent bossEvent = (ServerBossEvent) new ServerBossEvent(this.getDisplayName(),
            BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_10).setDarkenScreen(true);
    private int pulseCooldown = 60;
    private int chargeTicks;
    private boolean enraged;

    public ResonantColossus(EntityType<? extends ResonantColossus> type, Level level) {
        super(type, level);
        this.xpReward = 150;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ATTACK_DAMAGE, 14.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 4.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_CHARGING, false);
    }

    public boolean isCharging() {
        return this.entityData.get(DATA_CHARGING);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, HollowStalker.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        ServerLevel level = (ServerLevel) this.level();

        if (this.pulseCooldown > 0) {
            this.pulseCooldown--;
        }

        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive()) {
            if (this.chargeTicks > 0) {
                this.chargeTicks--;
                this.getNavigation().stop();
                this.getLookControl().setLookAt(target, 30.0F, 30.0F);
                spawnChargeParticles(level);
                if (this.chargeTicks == 0) {
                    this.entityData.set(DATA_CHARGING, false);
                    firePulse(level, target);
                    this.pulseCooldown = this.enraged ? 70 : 110;
                }
            } else if (this.pulseCooldown == 0 && this.distanceToSqr(target) < PULSE_RANGE_SQR
                    && this.distanceToSqr(target) > 16.0D && this.hasLineOfSight(target)) {
                this.chargeTicks = CHARGE_TIME;
                this.entityData.set(DATA_CHARGING, true);
                this.playSound(SoundEvents.WARDEN_SONIC_CHARGE, 3.0F, 0.8F);
            }
        } else if (this.chargeTicks > 0) {
            this.chargeTicks = 0;
            this.entityData.set(DATA_CHARGING, false);
        }

        if (!this.enraged && this.getHealth() < this.getMaxHealth() * 0.5F) {
            enrage(level);
        }
    }

    private void spawnChargeParticles(ServerLevel level) {
        Vec3 core = this.position().add(0.0D, this.getBbHeight() * 0.62D, 0.0D);
        for (int i = 0; i < 6; i++) {
            double ox = (this.random.nextDouble() - 0.5D) * 6.0D;
            double oy = (this.random.nextDouble() - 0.5D) * 4.0D;
            double oz = (this.random.nextDouble() - 0.5D) * 6.0D;
            // count 0: the offset vector becomes velocity, so motes rush into the chest core
            level.sendParticles(ModParticles.ECHO_MOTE.get(), core.x + ox, core.y + oy, core.z + oz, 0, -ox, -oy, -oz, 0.12D);
        }
    }

    private void firePulse(ServerLevel level, LivingEntity target) {
        Vec3 from = this.position().add(0.0D, this.getBbHeight() * 0.62D, 0.0D);
        Vec3 to = target.getEyePosition();
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        Vec3 dir = delta.normalize();
        for (double d = 1.0D; d < length; d += 0.5D) {
            Vec3 p = from.add(dir.scale(d));
            level.sendParticles(ModParticles.ECHO_MOTE.get(), p.x, p.y, p.z, 2, 0.08D, 0.08D, 0.08D, 0.01D);
            if (((int) (d * 2.0D)) % 6 == 0) {
                level.sendParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        if (target.hurt(this.damageSources().sonicBoom(this), this.enraged ? 14.0F : 10.0F)) {
            double resist = 1.0D - target.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE);
            target.push(dir.x * 1.8D * resist, 0.45D * resist, dir.z * 1.8D * resist);
        }
        this.playSound(SoundEvents.WARDEN_SONIC_BOOM, 3.0F, 1.2F);
    }

    private void enrage(ServerLevel level) {
        this.enraged = true;
        this.bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null && speed.getModifier(ENRAGE_SPEED_ID) == null) {
            speed.addPermanentModifier(new AttributeModifier(ENRAGE_SPEED_ID, "Colossus enrage", 0.3D,
                    AttributeModifier.Operation.MULTIPLY_BASE));
        }
        this.playSound(SoundEvents.WARDEN_ROAR, 4.0F, 0.7F);
        level.sendParticles(ParticleTypes.SCULK_SOUL, this.getX(), this.getY(0.6D), this.getZ(), 60, 1.2D, 1.5D, 1.2D, 0.08D);
        for (int i = 0; i < 2; i++) {
            HollowStalker stalker = ModEntities.HOLLOW_STALKER.get().create(level);
            if (stalker != null) {
                double angle = this.random.nextDouble() * Math.PI * 2.0D;
                stalker.moveTo(this.getX() + Math.cos(angle) * 3.0D, this.getY(), this.getZ() + Math.sin(angle) * 3.0D,
                        this.random.nextFloat() * 360.0F, 0.0F);
                stalker.setTarget(this.getTarget());
                level.addFreshEntity(stalker);
                level.sendParticles(ParticleTypes.SCULK_CHARGE_POP, stalker.getX(), stalker.getY(1.0D), stalker.getZ(),
                        30, 0.4D, 1.0D, 0.4D, 0.05D);
            }
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && this.level() instanceof ServerLevel level) {
            shockwave(level);
        }
        return hit;
    }

    private void shockwave(ServerLevel level) {
        double radius = 4.5D;
        List<LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(radius),
                e -> e != this && e.isAlive() && !(e instanceof HollowStalker));
        for (LivingEntity e : nearby) {
            e.hurt(this.damageSources().mobAttack(this), this.enraged ? 6.0F : 4.0F);
            e.knockback(1.2D, this.getX() - e.getX(), this.getZ() - e.getZ());
        }
        for (int i = 0; i < 48; i++) {
            double angle = (Math.PI * 2.0D * i) / 48.0D;
            double dx = Math.cos(angle);
            double dz = Math.sin(angle);
            level.sendParticles(ModParticles.ECHO_MOTE.get(), this.getX() + dx, this.getY() + 0.2D, this.getZ() + dz,
                    0, dx, 0.05D, dz, 0.6D);
        }
        level.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 0.3D, this.getZ(), 3, 1.0D, 0.1D, 1.0D, 0.0D);
        this.playSound(SoundEvents.WARDEN_ATTACK_IMPACT, 2.0F, 0.7F);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide && this.random.nextInt(2) == 0) {
            this.level().addParticle(ModParticles.ECHO_MOTE.get(),
                    this.getRandomX(1.0D), this.getY(0.75D + this.random.nextDouble() * 0.25D), this.getRandomZ(1.0D),
                    0.0D, 0.02D, 0.0D);
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (this.level() instanceof ServerLevel level) {
            level.sendParticles(ModParticles.ECHO_MOTE.get(), this.getX(), this.getY(0.5D), this.getZ(), 250, 1.5D, 2.0D, 1.5D, 0.25D);
            level.sendParticles(ParticleTypes.SCULK_SOUL, this.getX(), this.getY(0.5D), this.getZ(), 80, 1.5D, 2.0D, 1.5D, 0.1D);
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Enraged", this.enraged);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.enraged = tag.getBoolean("Enraged");
        if (this.enraged) {
            this.bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
        }
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getDisplayName());
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return 3.0F;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.RESONANT_COLOSSUS_AMBIENT.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.AMETHYST_BLOCK_BREAK;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.IRON_GOLEM_STEP, 1.5F, 0.6F);
    }

    @Override
    public float getVoicePitch() {
        return 0.6F + this.random.nextFloat() * 0.1F;
    }

    @Override
    protected float getSoundVolume() {
        return 2.0F;
    }
}
