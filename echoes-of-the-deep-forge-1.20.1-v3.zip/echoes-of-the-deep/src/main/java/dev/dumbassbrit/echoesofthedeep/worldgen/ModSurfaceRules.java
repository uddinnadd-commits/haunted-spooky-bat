package dev.dumbassbrit.echoesofthedeep.worldgen;

import dev.dumbassbrit.echoesofthedeep.registry.ModBiomes;
import dev.dumbassbrit.echoesofthedeep.registry.ModBlocks;
import net.minecraft.world.level.levelgen.SurfaceRules;

public final class ModSurfaceRules {
    private ModSurfaceRules() {
    }

    /** Echo Moss replaces grass on dry ground inside the Echoing Hollow. Everything else falls through to vanilla. */
    public static SurfaceRules.RuleSource makeRules() {
        SurfaceRules.RuleSource echoMoss = SurfaceRules.state(ModBlocks.ECHO_MOSS.get().defaultBlockState());
        SurfaceRules.ConditionSource atOrAboveWater = SurfaceRules.waterBlockCheck(-1, 0);

        return SurfaceRules.ifTrue(
                SurfaceRules.isBiome(ModBiomes.ECHOING_HOLLOW),
                SurfaceRules.ifTrue(
                        SurfaceRules.abovePreliminarySurface(),
                        SurfaceRules.ifTrue(
                                SurfaceRules.ON_FLOOR,
                                SurfaceRules.ifTrue(atOrAboveWater, echoMoss))));
    }
}
