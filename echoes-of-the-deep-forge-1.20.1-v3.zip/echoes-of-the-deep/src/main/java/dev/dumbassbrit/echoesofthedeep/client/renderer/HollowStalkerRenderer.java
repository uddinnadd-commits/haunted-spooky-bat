package dev.dumbassbrit.echoesofthedeep.client.renderer;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.client.model.HollowStalkerModel;
import dev.dumbassbrit.echoesofthedeep.entity.HollowStalker;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class HollowStalkerRenderer extends MobRenderer<HollowStalker, HollowStalkerModel<HollowStalker>> {
    private static final ResourceLocation TEXTURE = EchoesOfTheDeep.id("textures/entity/hollow_stalker.png");
    private static final ResourceLocation GLOW = EchoesOfTheDeep.id("textures/entity/hollow_stalker_glow.png");

    public HollowStalkerRenderer(EntityRendererProvider.Context context) {
        super(context, new HollowStalkerModel<>(context.bakeLayer(HollowStalkerModel.LAYER)), 0.5F);
        this.addLayer(new EmissiveLayer<>(this, GLOW));
    }

    @Override
    public ResourceLocation getTextureLocation(HollowStalker entity) {
        return TEXTURE;
    }
}
