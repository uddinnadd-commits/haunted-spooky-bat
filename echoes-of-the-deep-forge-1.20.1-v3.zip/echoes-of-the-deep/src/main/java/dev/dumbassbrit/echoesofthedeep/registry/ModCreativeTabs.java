package dev.dumbassbrit.echoesofthedeep.registry;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EchoesOfTheDeep.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.echoesofthedeep"))
                    .icon(() -> new ItemStack(ModItems.RESONANCE_BELL.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.RESONANCE_BELL.get());
                        output.accept(ModItems.RESONANT_SHARD.get());
                        output.accept(ModItems.RESONANT_CRYSTAL.get());
                        output.accept(ModItems.ECHO_MOSS.get());
                        output.accept(ModItems.HOLLOW_BLOOM.get());
                        output.accept(ModItems.HOLLOW_HEART.get());
                        output.accept(ModItems.COLOSSUS_CORE.get());
                        output.accept(ModItems.RESONANT_BLADE.get());
                        output.accept(ModItems.HOLLOW_STALKER_SPAWN_EGG.get());
                        output.accept(ModItems.ECHO_WISP_SPAWN_EGG.get());
                        output.accept(ModItems.RESONANT_COLOSSUS_SPAWN_EGG.get());
                    })
                    .build());

    private ModCreativeTabs() {
    }
}
