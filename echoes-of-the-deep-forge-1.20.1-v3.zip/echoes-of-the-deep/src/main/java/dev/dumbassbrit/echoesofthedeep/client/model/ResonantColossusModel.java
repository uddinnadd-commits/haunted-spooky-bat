package dev.dumbassbrit.echoesofthedeep.client.model;

import dev.dumbassbrit.echoesofthedeep.EchoesOfTheDeep;
import dev.dumbassbrit.echoesofthedeep.entity.ResonantColossus;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Geometry generated from the same spec as the skin texture, so UVs always line up. Animation is hand-written. */
@SuppressWarnings("unused")
public class ResonantColossusModel<T extends ResonantColossus> extends HierarchicalModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(EchoesOfTheDeep.id("resonant_colossus"), "main");
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart crystal1;
    private final ModelPart crystal2;
    private final ModelPart crystal3;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public ResonantColossusModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.rightArm = this.body.getChild("right_arm");
        this.leftArm = this.body.getChild("left_arm");
        this.crystal1 = this.body.getChild("crystal_1");
        this.crystal2 = this.body.getChild("crystal_2");
        this.crystal3 = this.body.getChild("crystal_3");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-9.0F, -22.0F, -6.0F, 18.0F, 22.0F, 12.0F).texOffs(16, 75).addBox(-3.0F, -17.0F, -7.5F, 6.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.1F, 0.0F, 0.0F));
        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(76, 34).addBox(-4.0F, -8.0F, -5.0F, 8.0F, 8.0F, 8.0F).texOffs(32, 75).addBox(3.0F, -12.0F, -2.0F, 2.0F, 5.0F, 2.0F).texOffs(40, 75).addBox(-5.0F, -12.0F, -2.0F, 2.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -22.0F, -2.0F, -0.1F, 0.0F, 0.0F));
        PartDefinition rightArm = body.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(60, 0).addBox(-8.0F, -3.0F, -4.0F, 8.0F, 24.0F, 8.0F).texOffs(0, 59).addBox(-8.5F, 20.0F, -4.5F, 9.0F, 7.0F, 9.0F).texOffs(100, 59).addBox(-7.0F, -8.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -19.0F, 0.0F, -0.1F, 0.0F, 0.0F));
        PartDefinition leftArm = body.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(92, 0).addBox(0.0F, -3.0F, -4.0F, 8.0F, 24.0F, 8.0F).texOffs(36, 59).addBox(-0.5F, 20.0F, -4.5F, 9.0F, 7.0F, 9.0F).texOffs(0, 75).addBox(3.0F, -8.0F, -2.0F, 4.0F, 6.0F, 4.0F), PartPose.offsetAndRotation(9.0F, -19.0F, 0.0F, -0.1F, 0.0F, 0.0F));
        PartDefinition crystal1 = body.addOrReplaceChild("crystal_1", CubeListBuilder.create().texOffs(72, 59).addBox(-2.0F, -10.0F, -2.0F, 4.0F, 10.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -20.0F, 5.0F, -0.3F, 0.0F, -0.3F));
        PartDefinition crystal2 = body.addOrReplaceChild("crystal_2", CubeListBuilder.create().texOffs(88, 59).addBox(-1.5F, -8.0F, -1.5F, 3.0F, 8.0F, 3.0F), PartPose.offsetAndRotation(4.0F, -18.0F, 5.0F, -0.4F, 0.0F, 0.35F));
        PartDefinition crystal3 = body.addOrReplaceChild("crystal_3", CubeListBuilder.create().texOffs(56, 34).addBox(-2.5F, -13.0F, -2.5F, 5.0F, 13.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 4.0F, -0.2F, 0.0F, 0.0F));
        PartDefinition rightLeg = root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(0, 34).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 18.0F, 7.0F), PartPose.offset(-5.0F, 6.0F, 0.0F));
        PartDefinition leftLeg = root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(28, 34).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 18.0F, 7.0F), PartPose.offset(5.0F, 6.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        float walk = limbSwing * 0.5F;
        this.rightLeg.xRot += Mth.cos(walk) * 0.9F * limbSwingAmount;
        this.leftLeg.xRot += Mth.cos(walk + Mth.PI) * 0.9F * limbSwingAmount;
        this.rightArm.xRot += Mth.cos(walk + Mth.PI) * 0.6F * limbSwingAmount;
        this.leftArm.xRot += Mth.cos(walk) * 0.6F * limbSwingAmount;
        this.body.zRot += Mth.cos(walk) * 0.06F * limbSwingAmount;
        this.head.yRot += netHeadYaw * Mth.DEG_TO_RAD * 0.7F;
        this.head.xRot += headPitch * Mth.DEG_TO_RAD * 0.5F;
        float breathe = Mth.sin(ageInTicks * 0.08F);
        this.body.y += breathe * 0.4F;
        this.crystal1.zRot += breathe * 0.03F;
        this.crystal2.zRot -= breathe * 0.03F;
        if (entity.isCharging()) {
            float shake = Mth.sin(ageInTicks * 2.5F) * 0.06F;
            this.rightArm.xRot -= 1.2F;
            this.leftArm.xRot -= 1.2F;
            this.rightArm.zRot += 0.6F + shake;
            this.leftArm.zRot -= 0.6F + shake;
            this.head.xRot -= 0.45F;
            this.crystal1.xRot += shake;
            this.crystal2.xRot -= shake;
            this.crystal3.zRot += shake;
        }
        if (this.attackTime > 0.0F) {
            float slam = Mth.sin(this.attackTime * Mth.PI);
            this.rightArm.xRot -= slam * 2.4F;
            this.leftArm.xRot -= slam * 2.4F;
            this.body.xRot += slam * 0.3F;
        }
    }
}
