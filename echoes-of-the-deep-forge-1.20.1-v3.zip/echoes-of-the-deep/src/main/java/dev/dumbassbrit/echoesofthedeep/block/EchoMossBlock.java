package dev.dumbassbrit.echoesofthedeep.block;

import dev.dumbassbrit.echoesofthedeep.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Teal ground cover that occasionally breathes out a drifting echo mote. */
public class EchoMossBlock extends Block {
    public EchoMossBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(40) == 0 && level.getBlockState(pos.above()).isAir()) {
            level.addParticle(ModParticles.ECHO_MOTE.get(),
                    pos.getX() + random.nextDouble(),
                    pos.getY() + 1.05D,
                    pos.getZ() + random.nextDouble(),
                    0.0D, 0.01D, 0.0D);
        }
    }
}
